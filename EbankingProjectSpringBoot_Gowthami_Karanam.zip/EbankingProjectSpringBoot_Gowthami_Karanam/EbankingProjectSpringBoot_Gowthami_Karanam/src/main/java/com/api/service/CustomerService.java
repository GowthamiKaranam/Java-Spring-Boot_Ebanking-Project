package com.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.dao.CustomerDao;
import com.api.model.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;

	public boolean registerCustomer(Customer customer) {

		try {
			customer=customerDao.save(customer);
			if(customer!=null&&customer.getCustomerId()!=0) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (Exception e) {
			return false;
		}

	}

	public List<Customer> getAllCustomer(){
		return customerDao.findAll();
	}

	public Customer getCustomerById(long customerId) {
	
		return customerDao.findById(customerId).orElse(new Customer());
	}

	public boolean updateCustomer(Customer customer) {
		try {
			customer=customerDao.save(customer);
			if(customer!=null&&customer.getCustomerId()!=0) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (Exception e) {
			return false;
		}

	}
}
