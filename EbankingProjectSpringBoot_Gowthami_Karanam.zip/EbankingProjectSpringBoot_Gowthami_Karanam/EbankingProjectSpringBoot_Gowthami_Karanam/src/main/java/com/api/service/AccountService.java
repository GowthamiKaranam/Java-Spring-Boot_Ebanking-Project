package com.api.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.dao.AccountDao;
import com.api.dao.CustomerDao;
import com.api.model.Account;
import com.api.model.AccountRequest;
import com.api.model.Customer;

@Service
public class AccountService {

	@Autowired
	AccountDao accountDao;

	@Autowired
	CustomerDao customerDao;

	public List<Account> getCustomerAccounts(long customerId) {
		
		Customer customer=customerDao.findById(customerId).orElseGet(null);

		if(customer==null)
			return null;

		return accountDao.findByCustomer(customer);
	}

	public boolean createAccount(AccountRequest account) {
		try {
			Customer customer=customerDao.findById(account.getCustomerId()).orElse(null);
			int min=576473;
			int max=Integer.MAX_VALUE;
			if(customer==null)
				return false;
			Account acc=new Account();
			acc.setCustomer(customer);
			acc.setAccountNumber((long)(Math.random()*(max-min+1))+min);
			acc.setAccountType(account.getAccountType());
			acc=accountDao.save(acc);
			
			if(account!=null&&acc.getAccountId()>0)
				return true;
			else
				return false;
		}
		catch (Exception e) {
			return false;
		}
	}

}
