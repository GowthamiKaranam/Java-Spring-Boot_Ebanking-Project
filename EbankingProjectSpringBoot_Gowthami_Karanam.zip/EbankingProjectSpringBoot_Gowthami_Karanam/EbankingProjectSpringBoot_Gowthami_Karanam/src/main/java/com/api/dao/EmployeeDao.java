package com.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.model.Employee;

public interface EmployeeDao extends JpaRepository<Employee, Long> {

	Employee findByEmail(String email);

}
