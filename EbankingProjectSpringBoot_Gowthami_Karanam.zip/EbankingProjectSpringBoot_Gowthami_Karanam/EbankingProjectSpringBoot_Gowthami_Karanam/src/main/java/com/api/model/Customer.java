package com.api.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private long customerId;
	
	private String firstName;
	
	private String lastName;
	
	private int age;
	
	private String gender;
	
	private String city;
	
	private String occupation;
	
	@Column(unique=true)
	private String email;

	@Column(unique=true)
	private long contact;
	
	private long annualIncome;
	
//	private String creditCard;
	
	private String accountType;
	
	
	
//	public List<Account> getAccounts() {
//		return accounts;
//	}
//
//	public void setAccounts(List<Account> accounts) {
//		this.accounts = accounts;
//	}
//
//	public List<Transaction> getTransaction() {
//		return transaction;
//	}
//
//	public void setTransaction(List<Transaction> transaction) {
//		this.transaction = transaction;
//	}

//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "customer", fetch = FetchType.LAZY)
//	private List<Account> accounts = new ArrayList<Account>();
//
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "customer", fetch = FetchType.LAZY)
//	private List<Transaction> transaction = new ArrayList<Transaction>();

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public long getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(long annualIncome) {
		this.annualIncome = annualIncome;
	}

//	public String getCreditCard() {
//		return creditCard;
//	}
//
//	public void setCreditCard(String creditCard) {
//		this.creditCard = creditCard;
//	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", gender=" + gender + ", city=" + city + ", occupation=" + occupation + ", email=" + email
				+ ", contact=" + contact + ", annualIncome=" + annualIncome + ", accountType=" + accountType + "]";
	}
	
	 

}
