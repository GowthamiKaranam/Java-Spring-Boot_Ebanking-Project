package com.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.model.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Long>{

}
