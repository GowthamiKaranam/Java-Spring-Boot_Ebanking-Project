package com.api.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.api.model.Account;
import com.api.model.AccountRequest;
import com.api.model.Customer;
import com.api.model.Employee;
import com.api.service.AccountService;
import com.api.service.CustomerService;
import com.api.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@Autowired
	CustomerService customerService;

	@Autowired
	AccountService accountSerice;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;


	private Logger logger=Logger.getLogger(getClass().getName());

	@GetMapping(value="/redirectToindex")
	public String redirectToindex() {
		return "redirect:/index";
	}

	@GetMapping(value="/index")
	public ModelAndView showIndex(@RequestParam(value = "error", required = false) String error,Model m, @RequestParam(value="serverMessage", required=false)String serverMessage)  {
		logger.info("\nInside index");
		if(error!=null) {
			String errorMsg="Please check your Email and Password";
			logger.info("\nThere is an error while logging in \nError : "+errorMsg);
			logger.info("\nThere is an error while logging in \nError : "+error);
			m.addAttribute("serverMessage", errorMsg);
		}
		if(error==null && serverMessage!=null )
			m.addAttribute("serverMessage", serverMessage);
		return new ModelAndView("index");
	}

	@GetMapping("/employee-registration-page")
	public ModelAndView registrationPageForEmployee() {
		return new ModelAndView("registerEmployee","employee",new Employee());
	}


	@PostMapping("register-employee")
	public ModelAndView registerEmployee(@ModelAttribute("employee") Employee employee) {
		employee.setPassword(passwordEncoder.encode(employee.getPassword()));
		Employee dbemployee=employeeService.registerEmployee(employee);
		logger.info("Employee "+dbemployee);
		String serverMessage=null;
		if(dbemployee==null) {
			serverMessage="Failed to create Employee as username Already exists with "+employee.getEmail();
		}
		else {
			serverMessage="Employee created successfully ";
		}
		//return "redirect:/index?serverMessage="+serverMessage;
		return new ModelAndView("index","serverMessage",serverMessage);

	}

	//Customer Actions
	@GetMapping("create-customer")
	public ModelAndView createCustomer() {

		return new ModelAndView("createCustomer","customer",new Customer());

	}

	@GetMapping(value="/home")
	public ModelAndView showHome(Model m) {
		logger.info("\nLogin Succesful");
		logger.info("\nInside Home");
		String usermail=(String) m.getAttribute("usermail");

		if(usermail==null) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();

			if ((auth!=null)
					&&(auth instanceof UsernamePasswordAuthenticationToken)
					&&auth.isAuthenticated())
			{

				UserDetails userDetail = (UserDetails) auth.getPrincipal();	
				usermail=userDetail.getUsername();

				m.addAttribute("usermail", usermail);



				logger.info("\nSession Attribute UserName :" + m.getAttribute("usermail"));

				return new ModelAndView("home");

			}

			else
				return new ModelAndView("index","serverMessage","Please Login to continue");

		}
		else
			return new ModelAndView("home");
	}

	@PostMapping("/register-customer")
	public ModelAndView registerCustomer(@ModelAttribute("customer")Customer customer) {
		String serverMessage=null;

		if(customerService.registerCustomer(customer)) {
			serverMessage="Customer succesfully created";
		}
		else {
			serverMessage="Failed to Create Customer";
		}
		System.out.println(serverMessage);
		return new ModelAndView("home","serverMessage",serverMessage);
	}

	@GetMapping("/view-customers")
	public ModelAndView viewCustomers() {
		List<Customer> customers=customerService.getAllCustomer();

		return new ModelAndView("viewCustomers","customers",customers);
	}

	@GetMapping("/viewAccount")
	public ModelAndView viewAccount(@RequestParam("id") long customerId) {
		List<Account> accounts=accountSerice.getCustomerAccounts(customerId);
		System.out.println(accounts);
		return new ModelAndView("viewAccount","accounts",accounts);

	}

	@GetMapping("/add-account")
	public ModelAndView addAccount() {
		return new ModelAndView("addAccount","account",new AccountRequest());
	}

	@PostMapping("/saveaccount")
	public ModelAndView saveAccount(@ModelAttribute("account")AccountRequest account) {
		String serverMessage=null;

		if(accountSerice.createAccount(account)) {
			serverMessage="Account succesfully created";
		}
		else {
			serverMessage="Failed to Create Account";
		}
		System.out.println(serverMessage);
		return new ModelAndView("home","serverMessage",serverMessage);
	}

	@GetMapping("/modify-customer")
	public ModelAndView modifyCustomerPage() {
		return new ModelAndView("modifyCustomer","customer",new Customer());
	}

	@PostMapping("/modify-customer")
	public ModelAndView modifyCustomer(@ModelAttribute(name = "customer")Customer customer) {

		if(customer!=null&&customer.getCustomerId()>0&&customer.getEmail()==null) {
			customer=customerService.getCustomerById(customer.getCustomerId());
			return new ModelAndView("modifyCustomer","customer",customer);
		}
		String serverMessage=null;
		if(customerService.updateCustomer(customer)) {
			serverMessage="Account succesfully created";
		}
		else {
			serverMessage="Failed to Create Account";
		}

		return new ModelAndView("home","serverMessage",serverMessage);

	}

	@GetMapping("/view-transaction")
	public ModelAndView viewTransactions() {
		return new ModelAndView("viewTransactions");
	}


}
