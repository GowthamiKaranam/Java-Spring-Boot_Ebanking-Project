package com.api.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.api.dao.EmployeeDao;
import com.api.model.Customer;
import com.api.model.Employee;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao employeeDao;

	public Employee registerEmployee(Employee employee) {

		try {
			Employee dbemployee=null;
			if(employee!=null)
			 dbemployee=employeeDao.findByEmail(employee.getEmail());
			if(dbemployee==null)	
				return employeeDao.save(employee);	
			else 	
				return null;
		}catch(Exception e){
			return null;
		}

	}




}
