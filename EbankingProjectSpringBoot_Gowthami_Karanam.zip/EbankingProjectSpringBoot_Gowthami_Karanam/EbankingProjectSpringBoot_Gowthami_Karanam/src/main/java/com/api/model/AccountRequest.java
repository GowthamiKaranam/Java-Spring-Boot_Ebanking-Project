package com.api.model;

public class AccountRequest {

	private long customerId;
	private String accountType;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "AccountRequest [customerId=" + customerId + ", accountType=" + accountType + "]";
	}
	
	
}
