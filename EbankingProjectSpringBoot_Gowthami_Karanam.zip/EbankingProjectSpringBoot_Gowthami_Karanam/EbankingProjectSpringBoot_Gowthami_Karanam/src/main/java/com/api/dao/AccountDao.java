package com.api.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.model.Account;
import com.api.model.Customer;

public interface AccountDao extends JpaRepository<Account, Long> {

	List<Account> findByCustomer(Customer customer);

}
