package com.pack.customer.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.pack.customer.dao.CustomerDao;
import com.pack.customer.model.AddAccount;
import com.pack.customer.model.Customer;
import com.pack.customer.controller.EmployeeServlet;


/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	CustomerDao cuDao=new CustomerDao();
    public EmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			String action=request.getParameter("action");
			System.out.println(action);
			switch(action)
			{
			case "add":
				insert(request,response);
			    break;
			case "update":
				update(request,response);
				break;
//			case "delete":
//				delete(request,response);
//				break;
			case "addAccount":
			     addAccount(request,response);
			     break;
			}
			 

		}

	protected void insert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{ 
		Customer customer=new Customer();
		customer.setFname(request.getParameter("fname"));
		customer.setLname(request.getParameter("lname"));
		customer.setAge(Integer.parseInt(request.getParameter("age")));	 
		customer.setGender(request.getParameter("gender"));
		customer.setCity(request.getParameter("city"));
		customer.setOccupation(request.getParameter("occupation"));
		customer.setEmail(request.getParameter("email"));
		customer.setPhonenumber(Integer.parseInt(request.getParameter("phone")));
		customer.setAnnuleincome(Integer.parseInt(request.getParameter("income")));
		customer.setAccounttype(request.getParameter("accounttype"));
		
		int i=cuDao.save(customer);
	   System.out.println(i);	
	   if(i>0){
		   RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");  			  
			rd.forward(request, response);
	    }  
		else{ 
			RequestDispatcher rd=request.getRequestDispatcher("ModifyCustomerError.jsp");  			  
			rd.forward(request, response);
	    }

}
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Customer customer=new Customer();
		 
		customer.setFname(request.getParameter("firstName"));
		customer.setLname(request.getParameter("lastName"));
		customer.setAge(Integer.parseInt(request.getParameter("age")));	 
		customer.setGender(request.getParameter("gender"));
		customer.setCity(request.getParameter("city"));
		customer.setOccupation(request.getParameter("occupation"));
		customer.setEmail(request.getParameter("email"));
		customer.setPhonenumber(Integer.parseInt(request.getParameter("phone")));
		customer.setAnnuleincome(Integer.parseInt(request.getParameter("income")));
		customer.setAccounttype(request.getParameter("accounttype"));
		System.out.println(customer);
		int i=cuDao.update(customer,Integer.parseInt(request.getParameter("id")));
		if(i>0){
			RequestDispatcher rd=request.getRequestDispatcher("view.jsp");  			  
			rd.forward(request, response);
	    }  
		else{ 
			RequestDispatcher rd=request.getRequestDispatcher("ModifyCustomerError.jsp");  			  
			rd.forward(request, response);
	    }
	} 
	
//		protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		 
//			AddAccount account = new AddAccount(Integer.parseInt(request.getParameter("id")),request.getParameter("accountType"));
//			int i=cuDao.delete(account);
//			if(i>0){
//				RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");  			  
//				rd.forward(request, response);
//				System.out.println("dsds");
//		    }  
//			else{ 
//				RequestDispatcher rd=request.getRequestDispatcher("ModifyCustomerError.jsp");  			  
//				rd.forward(request, response);
//		    }	
//}
		protected void addAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			AddAccount account = new AddAccount(Integer.parseInt(request.getParameter("cusID")),request.getParameter("accounttype"));
			System.out.println(account);
			int i=cuDao.addAccount(account);
			if(i>0){
				RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");  			  
				rd.forward(request, response);
		    }  
			else{ 
				RequestDispatcher rd=request.getRequestDispatcher("ModifyCustomerError.jsp");  			  
				rd.forward(request, response);
		    }
	   }
		
}