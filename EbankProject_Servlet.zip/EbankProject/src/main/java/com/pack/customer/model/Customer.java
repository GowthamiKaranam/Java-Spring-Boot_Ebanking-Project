package com.pack.customer.model;

public class Customer {
	
	
	
	@Override
	public String toString() {
		return "Customer [fname=" + fname + ", lname=" + lname + ", age=" + age + ", email=" + email + ", gender="
				+ gender + ", city=" + city + ", occupation=" + occupation + ", phonenumber=" + phonenumber
				+ ", annuleincome=" + annuleincome + ", accounttype=" + accounttype + ", id=" + id + "]";
	}
	private String fname;
	private String lname;
	private int age;
	private String email;
	private String gender;
	private String city;
	private String occupation;
	private int phonenumber;
	private int annuleincome;
	private String accounttype;
	 
	
	public int id;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public int getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	public int getAnnuleincome() {
		return annuleincome;
	}
	public void setAnnuleincome(int annuleincome) {
		this.annuleincome = annuleincome;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
