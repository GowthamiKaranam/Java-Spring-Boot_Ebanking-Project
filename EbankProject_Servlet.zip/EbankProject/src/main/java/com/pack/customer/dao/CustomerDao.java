package com.pack.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pack.customer.model.AddAccount;
import com.pack.customer.model.Customer;

public class CustomerDao {
	private static final int id = 0;
	public boolean checklogin(String username, String password) throws SQLException{
		
		Connection con=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		con=MySqlConn.getCon();
		
		String query="select * from employeelogin where employee_username=? and employee_password=?";
		ps=con.prepareStatement(query);
		ps.setString(1, username);
		ps.setString(2, password);
		rs=ps.executeQuery();
		if (rs.next()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	public   int save(Customer u){
		int status=0;
		System.out.println(u);
		try{
			Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into customercreate(firstname,lastname,age,occupation,city,email,gender,phone,income,accounttype,id) values(?,?,?,?,?,?,?,?,?,?,?)");
			//PreparedStatement psa=con.prepareStatement("insert into account(accounttype,accountDate,amount,accountstatus,cusID)values(?,?,?,?,?)");
			ps.setString(1,u.getFname());
		 	ps.setString(2,u.getLname());
			ps.setInt(3,u.getAge());
			ps.setString(4,u.getOccupation());
			ps.setString(5,u.getCity());
			ps.setString(6,u.getEmail());
			ps.setString(7,u.getGender());	
			ps.setInt(8,u.getPhonenumber());
			ps.setInt(9,u.getAnnuleincome());	
			ps.setString(10,u.getAccounttype());	
			int id=getAutoId();
		    //ps.setInt(10, id);
		   ps.setString(11,String.valueOf(id));
//			psa.setString(1,u.getAccounttype());
//         	psa.setString(2,String.valueOf(getAutoAccountNumber()));
//         	psa.setString(3,String.valueOf(id));
////			
	    status=ps.executeUpdate();
		    System.out.println(status);
		}catch(Exception e){System.out.println(e);}
		return status;
		
		
	}
	public int getAutoId() {
		try {
			Connection con = MySqlConn.getCon();
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery("select Max(id)from customercreate");
			rs.next();
			rs.getString("Max(id)");
			if (rs.getString("Max(id)") == null) {
				return 1;
			} else {
		        return Integer.parseInt(rs.getString("Max(id)"))+1;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return -1;
	}
	
	public long getAutoAccountNumber() {
		try {
			Connection con = MySqlConn.getCon();
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery("select Max(accountNumber)from account");
			rs.next();
			rs.getString("Max(accountNumber)");
			if (rs.getString("Max(accountNumber)") == null) {
				return 20000055500120l;
			} else {
		        return (Long.parseLong(rs.getString("Max(accountNumber)")))+1;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return -1;
	}

	

	
	public   int update(Customer u, int id){
		int status=0;
		try{
			Connection con=MySqlConn.getCon();
			  System.out.println(con);
			PreparedStatement ps=con.prepareStatement("update customercreate set firstname=?,lastname=?,age=?,occupation=?,city=?,email=?,gender=?,phone=?,income=?, accounttype=? where id=?");
			System.out.println(id);
			
			ps.setString(1,u.getFname());
		 	ps.setString(2,u.getLname());
			ps.setInt(3,u.getAge());
			ps.setString(4,u.getOccupation());
			ps.setString(5,u.getCity());
			ps.setString(6,u.getEmail());
			ps.setString(7,u.getGender());	
			ps.setInt(8,u.getPhonenumber());
			ps.setInt(9,u.getAnnuleincome());
			ps.setString(10,u.getAccounttype());	
		
			ps.setString(11,Integer.toString(id));
			
			status=ps.executeUpdate();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
	
	
	
	
//	public   int addAcount(int id){
//		int status=0;
//		try{
//			Connection con=MySqlConn.getCon();
//			PreparedStatement ps=con.prepareStatement("delete from customercreate where id=?");
//			ps.setInt(1,id);
//			status=ps.executeUpdate();
//		}catch(Exception e){System.out.println(e);}
//
//		return status;
//	}
//	public int delete(AddAccount account) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//	
	public int addAccount(AddAccount account)
	{
		int status=0;
		try{
		    Connection con=MySqlConn.getCon();
			PreparedStatement ps=con.prepareStatement("insert into account(cusID,accounttype)values(?,?)");
			ps.setString(1,String.valueOf(account.getId()));
		 	ps.setString(2,account.getAccountType());
			status=ps.executeUpdate();
		}
		catch(Exception e){
			System.out.println(e);
		}
		return status;
	}
	
}
