package com.pack.customer.dao;

public class ProblemState {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final String setBoldText = "\033[0;1m";
		System.out.println(setBoldText);
	}

}
